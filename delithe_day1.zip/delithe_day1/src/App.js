import React from 'react'
import './App.css';
import UseEffect from './components/UseEffect';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import CountingWithClass from './components/CountingWithClass';
import CountFunctionComponent from './components/CountFunctionalComponent';


export default function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/count" element={<CountingWithClass/>}></Route>
          <Route path="/countFun" element={<CountFunctionComponent/>}></Route>
          <Route path="/timer" element={<UseEffect/>}></Route>
        </Routes>
      </BrowserRouter>
    </div>
  )
}
