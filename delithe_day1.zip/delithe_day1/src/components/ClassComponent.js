import React, { Component } from 'react'

export default class ClassComponent extends Component {
    constructor(){
        super();
        this.message='Kai re Bhava'
    }
  render() {
    return (
      <div>
        <h2>{this.message}</h2>
      </div>
    )
  }
}
