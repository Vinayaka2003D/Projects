//this is a function based component for counting
//hooks concept in function component React.useState (0) is a method of hooks
import React from 'react'

function CountFunctionComponent() {
    const [count,setCount]=React.useState (0);
    function increment(){
        setCount(count+1)
    }
  return (
    <div>
      <br></br>
      <h1>Count:{count}</h1>
      <button onClick={increment}>Increment</button>
    </div>
  )
}

export default CountFunctionComponent