import React, { Component } from 'react'
import { BrowserRouter, Routes } from 'react-router-dom';
import CountFunctionComponent from './CountFunctionalComponent';

export default class CountingWithClass extends Component {
    constructor(){
        super();
        this.state = {
            count: 0,
            count2: 0,
            count3: 1,
            count4: 10000
        }
    }
    incrementCount = () => {
        this.setState({count: this.state.count + 1})
    }
    decrementCount = () => {
        this.setState({count2: this.state.count2 - 1 })
    }
    multiplicationCount = () => {
        this.setState({count3: this.state.count3 * 2})
    }
    divisionCount = () => {
        this.setState({count4: this.state.count4 / 2 })
    }
    resetCount = () => {
        this.setState({
            count: 0,
            count2: 0,
            count3: 1,
            count4: 10000  
        })
    }
  render() {
    return (
      <div>
        <h1>{this.state.count}</h1>
        <button type="button" class="btn btn-success" onClick={this.incrementCount}>Increment</button>
        <br/>
        <br/>
        <h1>{this.state.count2}</h1>
        <button type="button" class="btn btn-danger" onClick={this.decrementCount}>Decrement</button>
        <br/>
        <br/>
        <h1>{this.state.count3}</h1>
        <button type="button" class="btn btn-warning" onClick={this.multiplicationCount}>Multiply</button>
        <br/>
        <br/>
        <h1>{this.state.count4}</h1>
        <button type="button" class="btn btn-info" onClick={this.divisionCount}>Divide</button>
        <br/>
        <br/>
        <button type="button" class="btn btn-dark" onClick={this.resetCount}>Reset</button>
        <br/>
        <br/>
       
      </div>
    )
  }
}
