import React from 'react'

function Footers() {
  return (
    <div>
      <div class="card">
  <div class="card-header">
    Quote
  </div>
  <div class="card-body">
    <blockquote class="blockquote mb-0">
      <p>Mavshi chi thond</p>
      <footer class="blockquote-footer">Soujanya cho ghov <cite title="Source Title">Vinayaka</cite></footer>
    </blockquote>
  </div>
</div>
    </div>
  )
}

export default Footers
