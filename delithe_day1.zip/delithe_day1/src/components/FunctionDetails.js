import React from 'react'

function FunctionDetails(props) {
  return (
    <div>
      <h2>name: {props.name} </h2>
      <h2>Age: {props.age} </h2>
      <h2>Department: {props.depart} </h2>
    </div>
  )
}

export default FunctionDetails