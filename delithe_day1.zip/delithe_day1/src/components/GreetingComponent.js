import React from 'react'

function GreetingComponent(props) {
  return (
    <div>
      <h2>Good Morning {props.name}</h2>
    </div>
  )
}

export default GreetingComponent
