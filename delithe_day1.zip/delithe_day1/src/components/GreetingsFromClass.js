import React, { Component } from 'react'

export default class GreetingsFromClass extends Component {
   
  render() {
    return (
      <div>
        <h1>Hello {this.props.name}</h1>
        <h2>Age: {this.props.age}</h2>
      </div>
    )
  }
}
