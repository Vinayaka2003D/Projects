import React, {useEffect, useState} from 'react'

function UseEffect() {
      const [count, setCount]=useState(0);

      useEffect(()=> {
        const timer = setInterval(() => setCount(count + 1), 1000);
        return () => clearInterval(timer);
      },[count]);
      <div></div>
      return <div>
        <h1>Count: {count}</h1>
        <br/>
        <br/>
        <button type="button" class="btn btn-dark" >Reset</button>
        </div>;
}

export default UseEffect
